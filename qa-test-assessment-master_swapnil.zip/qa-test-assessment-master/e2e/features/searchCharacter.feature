Feature: Search for character (person)

Scenario Outline: Validate result when searched with valid character
 Given The app is open on "localhost"
 When  You search for character "<person>"
 Then  Personal details for "<person>" are displayed

 Examples:
     |person|
     |Luke Skywalker|
     |Leia Organa|
     |r2|
     |Darth| 

Scenario: Validate result when searched with invalid character
 Given The app is open on "localhost" 
 When  You search for character "invalid"
 Then  Result is displayed as Not Found

