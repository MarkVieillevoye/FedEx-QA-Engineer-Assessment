Feature: Search for Planet

    Scenario Outline: Validate result when searched with valid planet
       Given The app is open on "localhost"
       When You search for planet "<planet>"
       Then Planet details for "<planet>" are displayed

        Examples:
        |planet|
        |Alderaan|
        |Hoth|

    Scenario:  Validate result when searched with invalid planet
       Given The app is open on "localhost"
       When You search for planet "invalid"
       Then Result is displayed as Not Found