Feature: Additional Flows

Scenario Outline: To verify previous Search Results for Person are removed
        Given The app is open on "localhost"
        When You search for character "<characterName>"
        Then Character details for "<characterName>" are displayed
        When Search form is cleared and clicked Search
        Then Previous search results are cleared

        Examples:
        |characterName|
        |Leia Organa|

Scenario Outline: To verify previous Search Results for planet are removed
        Given The app is open on "localhost"
        When You search for planet "<planetName>"
        Then Planet details for "<planetName>" are displayed
        When Search form is cleared and clicked Search
        Then Previous search results are cleared

        Examples:
        |planetName|
        |Alderaan|

Scenario Outline: To verify error message on switching radio button after successful result displayed
        Given The app is open on "localhost"
        When You search for character "<characterName>"
        Then Character details for "<characterName>" are displayed
        When Radio button is switched from character to planet
        Then Search result is displayed as Not Found

        Examples:
        |characterName|
        |Leia Organa|