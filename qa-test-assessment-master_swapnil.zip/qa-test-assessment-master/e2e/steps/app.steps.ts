export{}

const { Given, When, Then } = require('cucumber');
const { browser, by } = require('protractor');
const chai = require('chai');
chai.use(require('chai-as-promised'));


Given('The app is open on {string}', { timeout: 25 * 1000 }, async (string) => {
    await browser.get('http://' + string + ':4210/');
    await browser.sleep(2000);
    await chai.expect(browser.element(by.id('query')).isDisplayed()).to.eventually.be.true;
});

When(/^You search for character "(.*?)"$/, async (string) => {
    await browser.element(by.id('query')).sendKeys(string);
    await browser.element(by.tagName('button')).click();
});

Then(/^Personal details for  "(.*?)" are displayed$/, async () => {
    
    // get number of app-character cards displayed and verify that at least 1 app-character card is displayed
    let searchCharacterResults = browser.element.all(by.tagName('app-character'));
   

});

Then('Result is displayed as Not Found', async () => {
    browser.sleep(3000);
    await chai.expect(browser.element(by.css('div.col > div')).getText()).to.eventually.equals('Not found.');
});

When(/^You search for planet "(.*?)"$/, async (string) => {
    await browser.element(by.id('planets')).click();
    await browser.element(by.id('query')).sendKeys(string);
    await browser.element(by.tagName('button')).click();
    
});

Then(/^Planet details for "(.*?)" are displayed$/, async () => {

    // get number of app-planet cards displayed and verify that at least 1 app-planet card is displayed
    let searchPlanetResults= browser.element.all(by.tagName('app-planet'));
       
});

When('Search form is cleared and clicked Search', async () => {
    await browser.element(by.id('query')).clear();
    await browser.element(by.tagName('button')).click();
});

Then('Previous search results are cleared', async () => {
    await chai.expect(browser.element.all(by.tagName('app-character')).isDisplayed()).to.eventually.be.false;
    await chai.expect(browser.element.all(by.tagName('app-planet')).isDisplayed()).to.eventually.be.false;
});

When('Radio button is switched from character to planet', async () => {
    // selecting planet radio button and searching
    await browser.element(by.id('planets')).click();
    await browser.element(by.tagName('button')).click();
});