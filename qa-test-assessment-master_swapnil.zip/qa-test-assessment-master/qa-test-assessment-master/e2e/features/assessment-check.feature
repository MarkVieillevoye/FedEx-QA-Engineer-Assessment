Feature: Check the installation of the protractor framework
    
    Scenario: Open the browser
        Given The app is open on "localhost"

    Scenario: Intiate the search
        Given The app is open on "localhost"
        When I search "Luke Skywalker"
        And I click the Search button
        
      
  Scenario: Intiate the search with invalid data
        When I search "?%^&"
        And I click the Search button  


